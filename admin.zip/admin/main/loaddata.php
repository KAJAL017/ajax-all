<?php 
include('db.php');
$sql="SELECT * FROM `students` WHERE 1";
$row  = mysqli_query($conn,$sql);
$str="";
if($row->num_rows>0){
    while($data=mysqli_fetch_assoc($row)){

        $str.="<option class='form-control' value='{$data['id']}'>{$data['name']}</option>";
    }
}
else{
    $str.="<option >NO DATA FOUND</option>";
}


echo $str;



?>