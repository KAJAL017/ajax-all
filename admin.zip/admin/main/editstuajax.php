<?php 
include('db.php');
if($_POST['stuid']){
    $id=$_POST['stuid'];
}
$fetch="SELECT * FROM `students` WHERE `id`='$id'";
$result = mysqli_query($conn,$fetch);
$ret = mysqli_fetch_assoc($result); 
print(json_encode($ret, JSON_PRETTY_PRINT));


?>