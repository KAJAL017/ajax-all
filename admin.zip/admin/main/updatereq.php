<?php 
include('db.php');
if(
    isset($_POST['upid']) &&  
    isset($_POST['name']) &&  
    isset($_POST['email']) &&
    isset($_POST['phone']) &&
    isset($_POST['gender']) &&
    isset($_POST['age']) &&
    isset($_POST['class']) &&
    isset($_POST['course']) &&
    isset($_POST['state'])
); 
$upid = $_POST['upid'];
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$gender = $_POST['gender'];
$age = $_POST['age'];
$class = $_POST['class'];
$course = $_POST['course'];
$state = $_POST['state'];

$insert="UPDATE `students` SET `name`='$name',`email`='$email',`phone`='$phone',`gender`='$gender',`age`='$age',`class`='$class',`course`='$course',`state`='$state' WHERE `id`='$upid'";
mysqli_query($conn,$insert);





?>