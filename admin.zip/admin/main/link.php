<?php 
$assets="../../../php/admin/files/assets/";
$bootstrap="../../../php/admin/files/bootstrap/";
$plugins="../../../php/admin/files/plugins/";
$link="../../../php/admin/pages/";
$header="../../../php/admin/main/header.php";



?>