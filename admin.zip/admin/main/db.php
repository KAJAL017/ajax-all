<?php 
$conn=mysqli_connect('localhost','root','','collage');
$result_array = array();


?>