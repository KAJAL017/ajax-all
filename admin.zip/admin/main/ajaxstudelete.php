<?php 
include_once('db.php');
if($_GET['studentid']){
    $id=$_GET['studentid'];
}
$del = "DELETE from students where `id` = '$id'";
mysqli_query($conn,$del);

?>