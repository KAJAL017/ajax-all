<?php 
include('db.php');
if(
    isset($_POST['name']) &&  
    isset($_POST['email']) &&
    isset($_POST['phone']) &&
    isset($_POST['gender']) &&
    isset($_POST['age']) &&
    isset($_POST['class']) &&
    isset($_POST['course']) &&
    isset($_POST['state'])
); 
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$gender = $_POST['gender'];
$age = $_POST['age'];
$class = $_POST['class'];
$course = $_POST['course'];
$state = $_POST['state'];

$insert="INSERT INTO `students`(`name`, `email`, `phone`, `gender`, `age`, `class`, `course`, `state`) VALUES ('$name','$email','$phone','$gender','$age','$class','$course','$state')";
mysqli_query($conn,$insert);





?>