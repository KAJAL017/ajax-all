<?php 
include_once ('../admin/main/header.php')

?>

<!--  BEGIN NAVBAR  -->
<div class="sub-header-container">
    <header class="header navbar navbar-expand-sm">
        <a href="javascript:void(0);" class="sidebarCollapse" data-placement="bottom"><svg
                xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                class="feather feather-menu">
                <line x1="3" y1="12" x2="21" y2="12"></line>
                <line x1="3" y1="6" x2="21" y2="6"></line>
                <line x1="3" y1="18" x2="21" y2="18"></line>
            </svg></a>
    </header>
</div>
<!--  END NAVBAR  -->

<!--  BEGIN MAIN CONTAINER  -->
<div class="main-container" id="container">

    <div class="overlay"></div>
    <div class="search-overlay"></div>

    <?php include_once('../admin/main/sidebar.php')?>

    <!--  BEGIN CONTENT AREA  -->
    <div id="content" class="main-content">
        <div class="layout-px-spacing">
<br>
<br>
            <div class="container">
                <div class="statbox widget box box-shadow">
                    <div class="widget-header">
                        <div class="row">
                            <div class="col-xl-12 col-md-12 col-sm-12 col-12 ">
                                <h4>ADD STUDENTS</h4>
                            </div>
                        </div>
                    </div>
                    <div class="widget-content widget-content-area">
                        <form >
                            <div class="form-row mb-4">
                                <div class="col-6">
                                    <label for="">Name</label>
                                    <input type="text" class="form-control" placeholder="First name" id="stuname">
                                </div>
                                <div class="col-6">
                                <label for="">Email</label>
                                    <div class="input-group mb-5" >
                                        <input type="text" class="form-control" placeholder="Enter Your Email Address"
                                            aria-label="Enter Your Email Address" aria-describedby="basic-addon2" id="stuemail">
                                        <div class="input-group-append">
                                            <span class="input-group-text" id="basic-addon6">@example.com</span>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-6" style="margin-top:-30px">
                                    <label for="">Phone</label>
                                    <input type="text" class="form-control" placeholder="Enter Your Phone Number" id="stuphone">
                                </div>  
                                <div class="col-6" style="margin-top:-30px">
                                    <label for="">Gender</label>
                                    <select class="form-control  basic" id="stugender">
                                    <option selected="selected">Select</option>
                                    <option value="Male">Male</option>
                                    <option value="female">Female</option>
                                    </select>
                                </div>  
                                <div class="col-6 mt-3">
                                    <label for="">Age</label>
                                    <input type="number" class="form-control" placeholder="Enter Age Between 18-24" id="stuage"> 
                                </div>
                                <div class="col-6 mt-3">
                                <label for="">Class</label>
                                    <select class="form-control  basic" id="stuclass">
                                    <option selected="selected">Select</option>
                                    <option value="UG">UG</option>
                                    <option value="PG">PG</option>
                                    </select>
                                </div>
                                <div class="col-6 mt-3">
                                    <label for="">Course</label>
                                    <select class="form-control  basic" id="stucourse">
                                    <option selected>Select</option>
                                    <option value="BA">BA</option>
                                    <option value="BBA">BBA</option>
                                    <option value="BCA">BCA</option>
                                    <option value="BSC">BSC</option>
                                    </select>
                                </div>
                                <div class="col-6 mt-3">
                                    <label for="">State</label>
                                    <select name="state" class="form-control basic" id="stustate">
                                    <option selected >Select...</option>
                                    <option value="Andhra Pradesh">Andhra Pradesh</option>
                                    <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                                    <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                                    <option value="Assam">Assam</option>
                                    <option value="Bihar">Bihar</option>
                                    <option value="Chandigarh">Chandigarh</option>
                                    <option value="Chhattisgarh">Chhattisgarh</option>
                                    <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                                    <option value="Daman and Diu">Daman and Diu</option>
                                    <option value="Delhi">Delhi</option>
                                    <option value="Lakshadweep">Lakshadweep</option>
                                    <option value="Puducherry">Puducherry</option>
                                    <option value="Goa">Goa</option>
                                    <option value="Gujarat">Gujarat</option>
                                    <option value="Haryana">Haryana</option>
                                    <option value="Himachal Pradesh">Himachal Pradesh</option>
                                    <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                                    <option value="Jharkhand">Jharkhand</option>
                                    <option value="Karnataka">Karnataka</option>
                                    <option value="Kerala">Kerala</option>
                                    <option value="Madhya Pradesh">Madhya Pradesh</option>
                                    <option value="Maharashtra">Maharashtra</option>
                                    <option value="Manipur">Manipur</option>
                                    <option value="Meghalaya">Meghalaya</option>
                                    <option value="Mizoram">Mizoram</option>
                                    <option value="Nagaland">Nagaland</option>
                                    <option value="Odisha">Odisha</option>
                                    <option value="Punjab">Punjab</option>
                                    <option value="Rajasthan">Rajasthan</option>
                                    <option value="Sikkim">Sikkim</option>
                                    <option value="Tamil Nadu">Tamil Nadu</option>
                                    <option value="Telangana">Telangana</option>
                                    <option value="Tripura">Tripura</option>
                                    <option value="Uttar Pradesh">Uttar Pradesh</option>
                                    <option value="Uttarakhand">Uttarakhand</option>
                                    <option value="West Bengal">West Bengal</option>
</select>
                                </div>
                                
                                </div>
                                
                                <input type="button" value="Submit Now" class="btn btn-primary" onclick=storestudata()>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once('../admin/main/footer.php') ?>

<script>
    function storestudata(){
    let stuname = $('#stuname').val();
    let stuemail = $('#stuemail').val();
    let stuphone = $('#stuphone').val();
    let stugender = $('#stugender').val();
    let stuage = $('#stuage').val();
    let stuclass = $('#stuclass').val();
    let stucourse = $('#stucourse').val();
    let stustate = $('#stustate').val();
    $.ajax({
        type:'POST',
        url:'./main/ajaxreq.php',
        data:{
            name:stuname,
            email:stuemail,
            phone:stuphone,
            gender:stugender,
            age:stuage,
            class:stuclass,
            course:stucourse,
            state:stustate,
        },
        success:function(data){
         window.location.href = 'studentslist.php';
            
        }
    })

    }
</script>