<?php 
include_once ('../admin/main/header.php')

?>

<!--  BEGIN NAVBAR  -->
<div class="sub-header-container">
    <header class="header navbar navbar-expand-sm">
        <a href="javascript:void(0);" class="sidebarCollapse" data-placement="bottom"><svg
                xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                class="feather feather-menu">
                <line x1="3" y1="12" x2="21" y2="12"></line>
                <line x1="3" y1="6" x2="21" y2="6"></line>
                <line x1="3" y1="18" x2="21" y2="18"></line>
            </svg></a>
    </header>
</div>
<!--  END NAVBAR  -->

<!--  BEGIN MAIN CONTAINER  -->
<div class="main-container" id="container">

    <div class="overlay"></div>
    <div class="search-overlay"></div>

    <?php include_once('../admin/main/sidebar.php')?>

    <!--  BEGIN CONTENT AREA  -->
    <div id="content" class="main-content">
        <div class="layout-px-spacing">
<br>
<br>
            <div class="container">
                <div class="statbox widget box box-shadow">
                    <div class="widget-header">
                        <div class="row">
                            <div class="col-xl-12 col-md-12 col-sm-12 col-12 ">
                                <h4>DYNAMIC LIST</h4>
                            </div>
                        </div>
                    </div>
                    <div class="widget-content widget-content-area">
                        <form >
                            <div class="form-row ">  
                                <div class="col-6" >
                                    <label for="">STUDENT NAME</label>
                                    <select class="form-control  basic" id="name">
                                   <option selected>Select...</option>
                                    </select>
                                </div>  
                      
                                <div class="col-6">
                                    <label for="">Course</label>
                                    <select class="form-control  basic" id="stucourse">
                                    <option selected>Select</option>
                                    <option value="BA">BA</option>
                                    <option value="BBA">BBA</option>
                                    <option value="BCA">BCA</option>
                                    <option value="BSC">BSC</option>
                                    </select>
                                </div>
                                
                                </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('../admin/main/footer.php') ?>

<script>
    $(document).ready(function () {
        function loaddata(){
            $.ajax({
                type: "POST",
                url: "./main/loaddata.php",
                success: function (data) {  
                    console.log(data);
                    $('#name').append(data);
                }
            });
        }   
        loaddata();
        

    });
</script>
